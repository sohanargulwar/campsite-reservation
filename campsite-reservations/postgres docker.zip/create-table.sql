
CREATE TABLE CAMPSITE(
      id bigserial PRIMARY KEY NOT NULL,
      camp_site_name varchar(64) NOT NULL,
	  description varchar(64)
  );
  
  CREATE TABLE RESERVATION(
    uuid varchar(64) PRIMARY KEY NOT NULL,
	first_name varchar(64) NOT NULL,
	last_name varchar(64) NOT NULL,
	email_id varchar(64) NOT NULL,
    arrival_date timestamp NOT NULL,
    departure_date timestamp NOT NULL,
	campsite_id bigserial REFERENCES CAMPSITE(id)
  );
  
 